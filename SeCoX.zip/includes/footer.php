			</div>
		</div>

		<div id="footer">
			Copyright &copy; 2014
		</div><!-- footer -->
		
	</div><!-- page -->
	
</body>
</html>
<?php mysqli_close($mysqli);?>