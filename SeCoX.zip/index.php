<?php include('includes/header.php');?>

<h1>SeCoX</h1>
<hr>
<p>Semantic Content X-traction</p>

<?php include('includes/footer.php');?>